package com.company;

public class Main {

    public static void main(String[] args){
      Cliente cliente = new Cliente();
      cliente.setCredito(20);
      cliente.setNombre("Pepe villuela");
      cliente.setTelefono(639283);
      cliente.setEdad(32);
        System.out.println(cliente.getCredito());
        System.out.println(cliente.getNombre());
        System.out.println(cliente.getTelefono());
        System.out.println(cliente.getEdad());
    }
}

class Persona  {
    private int edad;
    private String nombre;
    private int telefono;
}

class Cliente extends Persona {
    private int credito;
    private String nombre;
    private int telefono;
    private int edad;

    //getteo y setteo el credito
    public void setCredito (int valor){
    this.credito = valor;
    }

    public int getCredito() {
        return credito;
    }

    //getteo y setteo el nombre
    public void setNombre (String valor){
        this.nombre = valor;
    }

    public String getNombre(){
        return nombre;
    }

    //getteo y setteo telefono
    public void setTelefono (int valor) {
        this.telefono = valor;
    }

    public int getTelefono(){
        return telefono;
    }

    //getteo y setteo edad
    public void setEdad (int valor) {
        this.edad = valor;
    }
    public int getEdad(){
        return edad;
    }
}

//creamos una clase final que no tiene herencia
final class Trabajador extends Persona {
    private int salario;
}